package com.clps.spring5.service;

public interface UserService {

	void updateUserInfo();
	
}
