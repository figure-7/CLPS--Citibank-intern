package com.clps.spring5.unittest;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.clps.spring5.bean.Emp;

public class Spring5Test {

//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext1.xml");
//	
//	@Test
//	public void testUser() {
//		// User user = new User();
//		User user = context.getBean("user", User.class);
//		System.out.println(user.getUsername());
//	}
//	
//	
//	@Test
//	public void testOrder() {
//		Order order = context.getBean("order", Order.class);
//		order.printAddress();
//	}

	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext2.xml");
//
//	@Test
//	public void testServiceDao() {
//		UserService userService = context.getBean("userService", UserServiceImpl.class);
//		userService.updateUserInfo();
//	}

	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext3.xml");
	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext4.xml");

	@Test
	public void testEmpDept() {
		Emp emp = context.getBean("emp", Emp.class);
		emp.printEmpInfo();
	}
	
	
	
	// xml ע�뼯������
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext5.xml");
//
//	@Test
//	public void testStudnet() {
//		Student student = context.getBean("student", Student.class);
//		student.print();
//	}
	
	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext6.xml");
//
//	@Test
//	public void testBook() {
//		Book book = context.getBean("book", Book.class);
//		book.print();
//	}
	
	
	// FactoryBean
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext7.xml");
//
//	@Test
//	public void testFactoryBean() {
//		Course course = context.getBean("myFactoryBean", Course.class);
//		System.out.println(course);
//	}
	
	
	
	// bean��������
//	@Test
//	public void testLifeCycle() {
//		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext9.xml");
//		Orders orders = context.getBean("orders", Orders.class);
//		System.out.println(orders);
//		System. out .println("4. ��ȡ���� bean ʵ������");
//		System. out .println(orders);
//		// bean ʵ������
//		context.close();
//	}
	
	// bean���ô�����
//	@Test
//	public void testBeanPostProcessor() {
//		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext9.xml");
//		MyBeanPostProcessor myBeanPostProcessor = context.getBean("myBeanPostProcessor", MyBeanPostProcessor.class);
//		System.out.println(myBeanPostProcessor);
//		System. out .println("4. ��ȡ���� bean ʵ������");
//		System. out .println(myBeanPostProcessor);
//		// bean ʵ������
//		context.close();
//	}
	
}
