package com.clps.spring5.bean;

public class Emp {

	private String ename;
	private String gender;
	
	// Ա������ĳһ�����ţ�ʹ�ö�����ʽ��ʾ
	private Dept dept;

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public void printEmpInfo() {
		System.out.println(ename + ", " + gender + ", " + dept);
	}

}
