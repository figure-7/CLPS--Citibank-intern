package com.clps.spring5.dao;

public class UserDaoImpl implements UserDao {

	@Override
	public void updateUserInfo() {
		System.out.println("Update User Info");
	}

}
