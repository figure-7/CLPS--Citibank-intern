package com.clps.spring5.bean;

public class Order {

	private String address;

	// constructorע��
	public Order(String address) {
		this.address = address;
	}
	
	public void printAddress() {
		System.out.println(address);
	}
	
}

