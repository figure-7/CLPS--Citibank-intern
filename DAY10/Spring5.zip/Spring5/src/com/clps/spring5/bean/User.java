package com.clps.spring5.bean;

public class User {

	private String username;

	public String getUsername() {
		return username;
	}

	// setע��
	public void setUsername(String username) {
		this.username = username;
	}
	
}

