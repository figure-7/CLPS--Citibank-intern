package com.clps.spring5.aop.proxy;

public interface UserDao {

	String add(String name);
	
}
