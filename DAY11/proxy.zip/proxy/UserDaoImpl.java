package com.clps.spring5.aop.proxy;

public class UserDaoImpl implements UserDao {

	@Override
	public String add(String name) {
		System.out.println("add username");
		return name;
	}

}
