package com.clps.spring5.bean;

import org.springframework.beans.factory.FactoryBean;

public class MyFactoryBean implements FactoryBean<Course> {

	// ���巵�� bean
	@Override
	public Course getObject() throws Exception {
		Course course = new Course();
		course.setCname("Angular");
		return course;
	}

	@Override
	public Class<?> getObjectType() {
		return null;
	}

	@Override
	public boolean isSingleton() {
		return false;
	}

}
