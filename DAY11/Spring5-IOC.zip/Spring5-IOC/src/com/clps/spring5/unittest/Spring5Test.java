package com.clps.spring5.unittest;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.clps.spring5.annotation.bean.User;
import com.clps.spring5.annotation.config.ApplicationContextConfig;

public class Spring5Test {

//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext01.xml");
//	
//	@Test
//	public void testUser() {
//		// User user = new User();
//		User user = context.getBean("user", User.class);
//		
//		// scope="singleton" | "prototype"
//		User user2 = context.getBean("user", User.class);
//		User user3 = context.getBean("user", User.class);
//		System.out.println(user == user2);
//		System.out.println(user);
//		System.out.println(user2);
//		System.out.println(user3);
//		
//		System.out.println(user.getUsername());
//	}
//	
//	
//	@Test
//	public void testOrder() {
//		Order order = context.getBean("order", Order.class);
//		order.printAddress();
//	}

	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext02.xml");
//
//	@Test
//	public void testServiceDao() {
//		UserService userService = context.getBean("userService", UserServiceImpl.class);
//		userService.updateUserInfo();
//	}

	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext03.xml");
//	// ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext04.xml");
//
//	@Test
//	public void testEmpDept() {
//		Emp emp = context.getBean("emp", Emp.class);
//		emp.printEmpInfo();
//	}
	
	
	
	// xml ע�뼯������
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext05.xml");
//
//	@Test
//	public void testStudnet() {
//		Student student = context.getBean("student", Student.class);
//		student.print();
//	}
	
	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext06.xml");
//
//	@Test
//	public void testBook() {
//		Book book = context.getBean("book", Book.class);
//		book.print();
//	}
	
	
	
	// FactoryBean
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext07.xml");
//
//	@Test
//	public void testFactoryBean() {
//		Course course = context.getBean("myFactoryBean", Course.class);
//		System.out.println(course);
//	}
	
	
	
	// bean�������� �� bean���ô�����
//	// ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext08.xml");
//	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext09.xml");
//	
//	@Test
//	public void testLifeCycleAndPostProcessor() {
//		Orders orders = context.getBean("orders", Orders.class);
//		System.out.println("4. ��ȡ���� bean ʵ������    ");
//		// IOC�����رգ�beanʵ������
//		context.close();
//	}
	
	
	
	// Annotation
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext10.xml");
//	
//	@Test
//	public void testAnnotation() {
//		User user = context.getBean("user", User.class);
//		user.createUser();
//		System.out.println(user);    // @Value
//		
//		User2 user2 = context.getBean("qwerasdfas", User2.class);
//		user2.createUser();
//	}
	
	
	
//	ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext11.xml");
//	
//	@Test
//	public void testAnnotation() {
//		UserService userService = context.getBean("userService", UserServiceImpl.class);
//		userService.updateUserInfo();
//	}
	
	
	// ���������࣬��ȫʹ��ע�⿪��
	ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationContextConfig.class);
	
	@Test
	public void testAnnotation() {
		User user = context.getBean("user", User.class);
		user.createUser();
	}
	
}
