package com.clps.spring5.annotation.bean;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

// ��IoC�������������
@Component
public class User {

	@Value(value = "Tom")
	private String username;

	public void createUser() {
		System.out.println("User is created");
	}

	@Override
	public String toString() {
		return "User [username=" + username + "]";
	}

}
