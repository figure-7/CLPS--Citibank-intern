package com.clps.spring5.annotation.service;

public interface UserService {

	void updateUserInfo();
	
}
