package com.clps.spring5.annotation.bean;

import org.springframework.stereotype.Component;

@Component(value = "qwerasdfas")
public class User2 {

	public void createUser() {
		System.out.println("User2 is created ...... ");
	}

}
