package com.clps.spring5.annotation.dao;

import org.springframework.stereotype.Repository;

@Repository(value="asdfdfgsdfgsdfgdfgsdf")
public class UserDaoImpl implements UserDao {

	@Override
	public void updateUserInfo() {
		System.out.println("Update User Info");
	}

}
