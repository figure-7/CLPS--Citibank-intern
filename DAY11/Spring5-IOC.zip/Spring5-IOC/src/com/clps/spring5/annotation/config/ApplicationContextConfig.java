package com.clps.spring5.annotation.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = { "com.clps.spring5.annotation" })
public class ApplicationContextConfig {

}
