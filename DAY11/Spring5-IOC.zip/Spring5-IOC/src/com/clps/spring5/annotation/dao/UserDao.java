package com.clps.spring5.annotation.dao;

public interface UserDao {

	void updateUserInfo();
	
}
