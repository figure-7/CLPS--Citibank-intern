package com.clps.spring5.annotation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clps.spring5.annotation.dao.UserDao;

// <bean id="userService" class="com.clps.spring5.annotation.service.UserServiceImpl"></bean>
@Service(value="userService")
public class UserServiceImpl implements UserService {

	// ����ע������ע�⣬����Ҫ���� set ����
	@Autowired
	private UserDao userDao;
	
	
//	@Autowired
//	@Qualifier(value="asdfdfgsdfgsdfgdfgsdf")
//	private UserDao userDao;
	
	
//	@Resource
//	private UserDao userDao;
	
//	@Resource(name="asdfdfgsdfgsdfgdfgsdf")
//	private UserDao userDao;

	
//	public void setUserDao(UserDao userDao) {
//		this.userDao = userDao;
//	}

	@Override
	public void updateUserInfo() {
		userDao.updateUserInfo();
	}
	
}
