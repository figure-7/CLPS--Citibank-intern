package com.clps.spring5.dao;

public interface UserDao {

	void updateUserInfo();
	
}
