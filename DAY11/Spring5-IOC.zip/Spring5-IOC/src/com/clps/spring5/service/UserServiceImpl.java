package com.clps.spring5.service;

import com.clps.spring5.dao.UserDao;

public class UserServiceImpl implements UserService {

	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	@Override
	public void updateUserInfo() {
		userDao.updateUserInfo();
	}
	
}
