// debugger
console.log("This is my first JavaScript project!");

alert("This is my first JavaScript project!");

document.writeln("This is my first JavaScript project!");
