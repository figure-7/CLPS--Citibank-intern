package com.clpstraining;

public class WithoutSynchronizationExample {
    public static void main(String args[]) {
        Table obj = new Table();// only one object
        Table obj2 = new Table();// only one object

        // obj.testString();
        MyThread1 t1 = new MyThread1(obj);
        MyThread2 t2 = new MyThread2(obj);

        t1.start();
        t2.start();
    }
}

class Table {

    // private final static Object lockObject = new Object();

    // void testString() {
    // String a = "qwer";
    // String b = "qwer";
    // String c = new String("qwer");
    // String d = new String();
    //
    // System.out.println(a == b);
    // System.out.println("qwer".equals(b));
    // System.out.println(b.equals("qwer"));
    // System.out.println(c == d);
    // System.out.println(c.equals(d));
    // System.out.println(a.equals(c));
    // }

    synchronized static void printTable(int n) {// method not synchronized
            for (int i = 1; i <= 10; i++) {
                System.out.println(n * i);
                try {
                    Thread.sleep(400);
                } catch (Exception e) {
                    System.out.println(e);
                }
            }

    }
}

class MyThread1 extends Thread {
    Table t;

    MyThread1(Table t) {
        this.t = t;
    }

    @Override
    public void run() {
        t.printTable(5);
    }

}

class MyThread2 extends Thread {
    Table t;

    MyThread2(Table t) {
        this.t = t;
    }

    public void run() {
        t.printTable(100);
    }
}