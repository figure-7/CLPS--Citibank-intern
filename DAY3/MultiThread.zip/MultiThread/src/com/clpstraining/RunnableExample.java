package com.clpstraining;

public class RunnableExample{

    public static void main(String[] args) {
        RunnableThread runnableThread = new RunnableThread();
        Thread runnableExample = new Thread(runnableThread);
        runnableExample.start();
    }

}

class RunnableThread implements Runnable{
    @Override
    public void run() {
        System.out.println("Runnable thread is working");
    }
}
