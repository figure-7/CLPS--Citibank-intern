package com.clpstraining;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.clpstraining.entity.Student;

public class MapExample {
    public static void main(String[] args) {
        Map<Integer, Student> map = new HashMap<>();
        map.put(1, new Student(1, "Zhang Yi", 1, "English", "Good person1"));
        map.put(2, new Student(2, "Zhang Er", 2, "Math", "Good person1"));
        map.put(3, new Student(3, "Zhang San", 3, "P.E.", "Good person1"));
        map.put(4, new Student(4, "Zhang Si", 2, "Chemitry", "Good person1"));
        map.put(5, new Student(5, "Zhang Wu", 1, "Math", "Good person1"));

        // System.out.println(map.get(1));

        for (Entry<Integer, Student> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue().toString());
        }

        for (Integer key : map.keySet()) {
            System.out.println(key + ": " + map.get(key));
        }

        List resultList = new ArrayList(map.values());

    }
}
