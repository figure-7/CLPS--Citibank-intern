package com.clpstraining;

public class CurrentThreadExample {
    public static void main(String[] args) {
        ThreadCurrent t1 = new ThreadCurrent(); 
        ThreadCurrent t2 = new ThreadCurrent(); 
        
        t1.start();
        t2.start();
    }
}

class ThreadCurrent extends Thread {
    public void run() {
        System.out.println(Thread.currentThread().getName());
    }
}