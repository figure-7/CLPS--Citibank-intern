package com.clpstraining;

public class StartThreadTwice {
    public static void main(String[] args) {
        TestThreadTwice1 t1=new TestThreadTwice1();  
        t1.start();  
        t1.start();
    }
}

class TestThreadTwice1 extends Thread {
    public void run() {
        System.out.println("running...");
    }
}