package com.clpstraining;

public class ThreadExample extends Thread {

    @Override
    public void run() {
        System.out.println("Thread running");
    }

    public static void main(String[] args) {
        ThreadExample myThread = new ThreadExample();
        myThread.start();
    }

}
