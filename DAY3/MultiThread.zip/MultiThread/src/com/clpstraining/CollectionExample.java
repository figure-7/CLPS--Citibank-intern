package com.clpstraining;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import com.clpstraining.entity.Student;

public class CollectionExample {

    public static void main(String[] args) {
        List<Student> toSaveStudents = new ArrayList<>();
        toSaveStudents.add(new Student(1, "Zhang Yi", 1, "English", "Good person1"));
        toSaveStudents.add(new Student(2, "Zhang Er", 2, "Biology", "Good person2"));
        toSaveStudents.add(new Student(3, "Zhang San1", 3, "Math", "Good person3"));
        toSaveStudents.add(new Student(3, "Zhang San2", 3, "Math", "Good person3"));
        toSaveStudents.add(new Student(3, "Zhang San3", 3, "Math", "Good person3"));
        toSaveStudents.add(new Student(3, "Zhang San4", 3, "Math", "Good person3"));
        toSaveStudents.add(new Student(4, "Zhang Si", 3, "Chemistry", "Good person4"));
        toSaveStudents.add(new Student(5, "Zhang Wu", 3, "P.E.", "Good person5"));
        toSaveStudents.add(new Student(5, "Zhang Wu", 3, "P.E.", "Good person5"));
        toSaveStudents.add(new Student(5, "Zhang Wu", 3, "P.E.", "Good person5"));

        Student student;
        // Iterator
        ListIterator<Student> listIterator = toSaveStudents.listIterator();
        while (listIterator.hasNext()) {
            student = (Student)listIterator.next();
            if ("Math".equals(student.getMajor())) {
                toSaveStudents.remove(student);
                // listIterator.remove();
            }
            // System.out.println(student.toString());
        }

        // for i
        /*for (int i = 0; i < toSaveStudents.size(); i++) {
            student = toSaveStudents.get(i);
            if ("Math".equals(student.getMajor())) {
                toSaveStudents.remove(i);
            }
            // student.setComment("Change in for each");
        }*/

        // for each
        /*for (Student student2 : toSaveStudents) {
            if ("Math".equals(student2.getMajor())) {
                toSaveStudents.remove(student2);
            }
            // student2.setComment("Change in for each");
        }*/
        // System.out.println(toSaveStudents);
        for (Student student2 : toSaveStudents) {
            System.out.println(student2.toString());
        }
    }

}
