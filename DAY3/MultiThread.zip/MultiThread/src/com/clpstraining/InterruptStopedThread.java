package com.clpstraining;

public class InterruptStopedThread {
    public static void main(String args[]) {
        TestInterruptingThread t1 = new TestInterruptingThread();
        t1.start();
        t1.interrupt();
    }
}

class TestInterruptingThread extends Thread {
    public void run() {
        try {
            Thread.sleep(1000);
            for (int i = 1; i <= 5; i++) {
                System.out.println(i);
            }
            // for (int i = 1; i <= 2; i++) {
            // if (Thread.interrupted()) {
            // System.out.println("code for interrupted thread");
            // } else {
            // System.out.println("code for normal thread");
            // }
            // }
            System.out.println("task");
        } catch (InterruptedException e) {
            throw new RuntimeException("Thread interrupted..." + e);
            // System.out.println("Exception is handled: " + e.getMessage());
        }
        System.out.println("thread is running...");
    }
}
