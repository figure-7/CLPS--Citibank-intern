package com.clpstraining;

public class StaticSynchronizedExample {
    public static void main(String t[]) {
        MyTestThread1 t1 = new MyTestThread1();
        MyTestThread2 t2 = new MyTestThread2();
        MyTestThread3 t3 = new MyTestThread3();
        MyTestThread4 t4 = new MyTestThread4();
        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }
}

class MyTestThread1 extends Thread {
    public void run() {
        Table.printTable(1);
    }
}

class MyTestThread2 extends Thread {
    public void run() {
        Table.printTable(10);
    }
}

class MyTestThread3 extends Thread {
    public void run() {
        Table.printTable(100);
    }
}

class MyTestThread4 extends Thread {
    public void run() {
        Table.printTable(1000);
    }
}
